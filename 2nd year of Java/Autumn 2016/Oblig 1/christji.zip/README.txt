1. How to compile my program: javac Oblig1.java

2. Which file include in my main-method: Oblig1

3.
	 - Jeg antar ut ifra teksten at det alltid skal vaere tekst i filen.
	 - Jeg tolket oppgaveteksten som at det skal vaere en ordbok/oppslagsverk og derfor ikke behover duplikatord i listen.
	 - Jeg tolket ogsaa at utskrift.txt ikke skal skrives til ved hjelp av PrintWriter, men at vi heller limer inn svaret vi fikk etter programmet har kjort.
	 - Har ogsaa tolket oppgaven slik at alfabetet kun gaar fra a-z.
	-  Jeg har ogs� tolket gjennomsnittsdybden som at man regner alle dybdene, plusset sammen, delt paa antall noder.

4. - Oppgaven har blitt slik at kjoretiden blir oppgitt i millisekunder, men jeg har opplevd at det ikke alltid gir utslag, og da maa jeg bytte System.currentTimeMillis til System.nanoTime() for aa faa
		utskrift som ikke er 0.

5. GOOD (I hope...?)

6. Google :)
