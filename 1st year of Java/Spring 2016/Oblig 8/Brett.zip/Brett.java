public class Brett {

  Rute[][] brettet;
  int antRad;
  int antKolonne;


  public Brett(int antRad, int antKolonne) {
    this.antRad = antRad;
    this.antKolonne = antKolonne;
    brettet = new Rute[antRad*antKolonne][antRad*antKolonne];
  }

  public void setRute(Rute verdi, int radNR, int kolonneNR) {
    brettet[radNR][kolonneNR] = verdi;
  }

  public int getRad() {
    return antRad;
  }

  public int getKolonne() {
    return antKolonne;
  }

  public Rute getRute(int radNR, int kolonneNR) {
    return brettet[radNR][kolonneNR];
  }
}
