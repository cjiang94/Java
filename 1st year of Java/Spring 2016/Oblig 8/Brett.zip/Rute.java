public class Rute {

  private int verdi;

  public Rute(char verdi) {
    this.verdi = HjelpeMetoder.tegnTilVerdi(verdi);
  }

  public Rute() {
    this.verdi = 0;
  }

  public char getVerdi() {
    return HjelpeMetoder.verdiTilTegn(verdi);
  }
}
