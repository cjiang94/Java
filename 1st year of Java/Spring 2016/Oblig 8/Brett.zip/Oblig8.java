import java.util.Scanner;
import java.io.File;

public class Oblig8 {

  static Brett aktBrett = null;

  public static void main(String[] args) {

    try{
        lesFil("test.txt");
    } catch(Exception e) {
      System.out.println("Error: " + e.getMessage());
    }
  } // Avslutter main-klassen.

  public static void lesFil(String filnavn) throws Exception {

    Scanner in = new Scanner(new File(filnavn));

    String linje;
    int verdi;
    int rad = 0;
    int kolonne = 0;
    boolean lestBrett = false;
    int aktRad = 0;
    int charTeller = 0;

    while(in.hasNext()) {
      linje = in.nextLine();

      if(!lestBrett) {

        // Sjekker om ikke det blir lagd et for stort brett.
        if(Integer.parseInt(linje) >= 0 && Integer.parseInt(linje) <= 64) {
          rad = Integer.parseInt(linje);
        } else {
          throw new IllegalArgumentException("Radnummeret er enten under 0 eller over 64.");
        }

        linje = in.nextLine();

        // Sjekker om ikke det blir lagd et for stort brett.
        if(Integer.parseInt(linje) >= 0 && Integer.parseInt(linje) <= 64) {
          kolonne = Integer.parseInt(linje);
        } else {
          throw new IllegalArgumentException("Kolonnenummeret er enten under 0 eller over 64.");
        }

         lestBrett = true;
      } else {
      Oblig8.aktBrett = new Brett(rad, kolonne);

        for(int i=0; i<linje.length(); i++) {
          // Sjekker om tall er innenfor 0 til rad*kolonne.
          if(HjelpeMetoder.tegnTilVerdi(linje.charAt(i)) <= rad*kolonne && HjelpeMetoder.tegnTilVerdi(linje.charAt(i)) >= 0) {
            verdi = HjelpeMetoder.tegnTilVerdi(linje.charAt(i));
            if (verdi != 0) {
            Rute nyRute = new Rute(linje.charAt(i));
            Oblig8.aktBrett.setRute(nyRute, rad, kolonne);
            System.out.println("Inne i if");
            } else {
              Oblig8.aktBrett.setRute(new Rute(), rad, kolonne);
            }
            charTeller++;
          } else {
            throw new IllegalArgumentException("Tall utenfor lovlig intervall.");
          }

      }
      aktRad++;
    }

    } // Avslutter while-lokken

      if(charTeller != (rad*kolonne)*(rad*kolonne)) {
        throw new IllegalArgumentException("bleh");
      }

      System.out.println ("Opprettet nytt brett." + Oblig8.aktBrett.getRute(0,0));
      int test = 0;

      for(int a=0; a<36; a++) {
      System.out.println("aktrad: " + test + ", a: " + a + ", verdi: " + Oblig8.aktBrett.getRute(test, a).getVerdi());
      test++;
      }

  } // Avslutter metoden lesFil.


} // Avslutter Oblig8.
